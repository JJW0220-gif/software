"use strict";
cc._RF.push(module, '29e8ajSEnBFVozjjUrj55Pc', 'flower');
// scripts/flower.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var FlowerEnemy = /** @class */ (function (_super) {
    __extends(FlowerEnemy, _super);
    function FlowerEnemy() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.moveSpeed = 50; // 上下移動速度
        _this.moveRange = 100; // 上下移動範圍
        _this.startY = 0; // 初始位置
        _this.direction = 1; // 移動方向
        return _this;
    }
    FlowerEnemy.prototype.onLoad = function () {
        this.startY = this.node.y; // 記錄初始位置
        // 禁用重力影響
        var rb = this.getComponent(cc.RigidBody);
        if (rb) {
            rb.gravityScale = 0; // 設置重力影響為 0
        }
        var rigidBody = this.getComponent(cc.RigidBody);
        if (rigidBody) {
            rigidBody.fixedRotation = true;
        }
    };
    FlowerEnemy.prototype.update = function (dt) {
        var _this = this;
        // 上下移動邏輯
        this.node.y += this.direction * this.moveSpeed * dt;
        // 超出範圍時反向
        if (this.node.y > this.startY + this.moveRange && this.direction > 0) {
            this.direction = 0; // 停止移動
            this.getComponent(cc.Animation).play("flower");
            // 1 秒後恢復移動
            this.scheduleOnce(function () {
                _this.direction = -1; // 反向向下移動
                _this.getComponent(cc.Animation).stop("flower");
            }, 1);
        }
        else if (this.node.y < this.startY && this.direction < 0) {
            this.direction = 1;
        }
    };
    __decorate([
        property
    ], FlowerEnemy.prototype, "moveSpeed", void 0);
    __decorate([
        property
    ], FlowerEnemy.prototype, "moveRange", void 0);
    FlowerEnemy = __decorate([
        ccclass
    ], FlowerEnemy);
    return FlowerEnemy;
}(cc.Component));
exports.default = FlowerEnemy;

cc._RF.pop();