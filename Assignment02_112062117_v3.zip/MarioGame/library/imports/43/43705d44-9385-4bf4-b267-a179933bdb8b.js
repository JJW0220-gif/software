"use strict";
cc._RF.push(module, '437051Ek4VL9LJnoXmTO9uL', 'camera');
// scripts/camera.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var CameraFollow = /** @class */ (function (_super) {
    __extends(CameraFollow, _super);
    function CameraFollow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = null; // 拖曳你的 Player 進來
        _this.followX = true;
        _this.followY = true;
        // 新增邊界屬性
        _this.minX = 10;
        _this.maxX = 7350;
        _this.minY = 0;
        _this.maxY = 300;
        _this.lifeBar = null; // 拖入血條節點
        _this.frame = null; // 拖入血條框
        _this.pause = null; //暫停icon
        _this.pausePage = null; //暫停頁面
        _this.continue = null; //繼續按鈕
        _this.quit = null; //退出按鈕 
        _this.timerLabel = null; // 拖入用於顯示倒數時間的 Label 節點
        _this.score = null; // 拖入用於顯示倒數時間的 Label 節點
        _this.gameover = null;
        return _this;
    }
    CameraFollow.prototype.update = function (dt) {
        if (!this.target)
            return;
        var cameraPos = this.node.position;
        var targetPos = this.target.position;
        // 計算要跟隨的目標座標
        var newX = this.followX ? targetPos.x : cameraPos.x;
        var newY = this.followY ? targetPos.y : cameraPos.y;
        // 限制邊界
        newX = Math.max(this.minX, Math.min(this.maxX, newX));
        newY = Math.max(this.minY, Math.min(this.maxY, newY));
        this.node.setPosition(newX, newY);
        this.updateLifeBarPosition();
    };
    CameraFollow.prototype.updateLifeBarPosition = function () {
        if (!this.lifeBar) {
            console.error("lifeBar 節點未正確綁定！");
            return;
        }
        // Camera 的左上角（世界座標）
        var canvasSize = cc.view.getVisibleSize();
        var offsetX = 10;
        var offsetY = -10;
        var worldTopLeft = this.node.convertToWorldSpaceAR(cc.v2(-431.083, 272.207));
        var worldTopLeft2 = this.node.convertToWorldSpaceAR(cc.v2(-353.404, 246.228));
        var worldTopright = this.node.convertToWorldSpaceAR(cc.v2(443.651, 267.599));
        var worldcenter = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
        var worldcenter2 = this.node.convertToWorldSpaceAR(cc.v2(2.858, 0));
        var worldcenter3 = this.node.convertToWorldSpaceAR(cc.v2(-67.605, -77.723));
        var worldcentertop = this.node.convertToWorldSpaceAR(cc.v2(-2.532, 260.798));
        var worldTopRight2 = this.node.convertToWorldSpaceAR(cc.v2(300.689, 267.599));
        var dead = this.node.convertToWorldSpaceAR(cc.v2(32.415, 0));
        // 將世界座標轉成 UI 所在父節點的本地座標
        var uiRoot = this.lifeBar.parent; // HPbar
        var uiRoot2 = this.pausePage.parent; // gameMgr
        var localPos = uiRoot.convertToNodeSpaceAR(worldTopLeft);
        var localPos2 = uiRoot.convertToNodeSpaceAR(worldTopLeft2);
        var localPos3 = uiRoot.convertToNodeSpaceAR(worldTopright);
        var localPos4 = uiRoot2.convertToNodeSpaceAR(worldcenter);
        var localPos5 = uiRoot2.convertToNodeSpaceAR(worldcenter2);
        var localPos6 = uiRoot2.convertToNodeSpaceAR(worldcenter3);
        var localPos7 = uiRoot.convertToNodeSpaceAR(worldcentertop);
        var localPos8 = uiRoot.convertToNodeSpaceAR(worldTopRight2);
        var localPos9 = uiRoot2.convertToNodeSpaceAR(dead);
        this.lifeBar.setPosition(localPos);
        this.frame.setPosition(localPos2);
        this.pause.setPosition(localPos3);
        this.pausePage.setPosition(localPos4);
        this.continue.setPosition(localPos5);
        this.quit.setPosition(localPos6);
        this.timerLabel.node.setPosition(localPos7);
        this.score.node.setPosition(localPos8);
        this.gameover.setPosition(localPos4);
    };
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "target", void 0);
    __decorate([
        property
    ], CameraFollow.prototype, "followX", void 0);
    __decorate([
        property
    ], CameraFollow.prototype, "followY", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "lifeBar", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "frame", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "pause", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "pausePage", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "continue", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "quit", void 0);
    __decorate([
        property(cc.Label)
    ], CameraFollow.prototype, "timerLabel", void 0);
    __decorate([
        property(cc.Label)
    ], CameraFollow.prototype, "score", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "gameover", void 0);
    CameraFollow = __decorate([
        ccclass
    ], CameraFollow);
    return CameraFollow;
}(cc.Component));
exports.default = CameraFollow;

cc._RF.pop();