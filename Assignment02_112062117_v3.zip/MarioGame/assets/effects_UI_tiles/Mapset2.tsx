<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Mapset2" tilewidth="16" tileheight="16" tilecount="208" columns="16">
 <image source="../others/Game_background.png" trans="ff00ff" width="256" height="223"/>
</tileset>
