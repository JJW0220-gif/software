<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Mapset" tilewidth="16" tileheight="16" tilecount="1204" columns="43">
 <image source="tileset.png" trans="ff00ff" width="688" height="450"/>
</tileset>
