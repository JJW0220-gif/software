const { ccclass, property } = cc._decorator;
import GameMgr from "./gameMgr";

@ccclass
export default class Player extends cc.Component {
    @property(cc.Node)
    gameMgrNode: cc.Node = null; // 用來綁定 GameMgr 節點

    @property({ type: cc.AudioClip })
    jumpSound: cc.AudioClip = null; // 跳躍音效

    @property({ type: cc.AudioClip })
    beatSound: cc.AudioClip = null; // 採人音效

    @property({ type: cc.AudioClip })
    PowerDown: cc.AudioClip = null; // 跳躍音效

    @property({ type: cc.AudioClip })
    PowerUp: cc.AudioClip = null; // 跳躍音效

    @property
    moveForce: number = 3000;

    @property
    maxMoveSpeed: number = 1000;

    @property
    jumpImpulse: number = 800;

    private rb: cc.RigidBody = null;
    private isGrounded: boolean = false;
    private moveDir: number = 0;
    private isBig: boolean = false; // 玩家是否處於變大狀態
    private isInvincible: boolean = false; // 玩家是否處於無敵狀態
    private isTouchingWall: boolean = false;

    onLoad() {
        cc.director.getPhysicsManager().enabled = true;
        /*cc.director.getPhysicsManager().debugDrawFlags = 
            cc.PhysicsManager.DrawBits.e_aabbBit |
            cc.PhysicsManager.DrawBits.e_jointBit |
            cc.PhysicsManager.DrawBits.e_shapeBit;*/

        cc.director.getPhysicsManager().gravity = cc.v2(0, -1200);
    }

    start() {
        this.rb = this.getComponent(cc.RigidBody);
        this.rb.fixedRotation = true;
        this.rb.linearDamping = 2.0; // 線性阻尼，摩擦力效果

        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
        if (!this.gameMgrNode) {
            console.error("gameMgrNode 未正確綁定！");
        } else {
            console.log("gameMgrNode 綁定成功:", this.gameMgrNode.name);
        }
    
    }

    update(dt: number) {
        if(this.node.x > 7700) {
            this.gameMgrNode.getComponent(GameMgr).win(); // 調用 GameMgr 的 gameOver 方法
        }
        if (this.node.y < -500) { // 假設 -500 是死亡邊界
            console.log("玩家超出邊界，死亡！");
            this.gameMgrNode.getComponent(GameMgr).gameOver(); // 調用 GameMgr 的 gameOver 方法
        }
        if (!this.rb) return;

        // 真實加速度 + 限速
        const velocity = this.rb.linearVelocity;

        if (this.moveDir !== 0 && Math.abs(velocity.x) < this.maxMoveSpeed) {
            const force = cc.v2(this.moveDir * this.moveForce, 0);
            this.rb.applyForceToCenter(force, true);
        }

        // 翻轉角色面向
        if (this.moveDir !== 0) {
            this.node.scaleX = this.moveDir > 0 ? 1 : -1;
        }

        const animation = this.node.getComponent(cc.Animation);

        if (this.isGrounded) {
            if (this.moveDir !== 0) {
                // 撥放行走動畫
                console.log("行走中");
                if (!animation.getAnimationState("walk").isPlaying) {
                    animation.play("walk");
                }
            } else {
                // 撥放 default 動畫
                console.log("靜止中");
                if (!animation.getAnimationState("default").isPlaying) {
                    animation.play("default");
                }
            }
        }

        // 若碰牆卡住，加入輕微向下力道避免懸空
        /*if (this.isTouchingWall && !this.isGrounded) {
            this.rb.linearVelocity = cc.v2(this.rb.linearVelocity.x, this.rb.linearVelocity.y - 10);
        }*/
    }

    onKeyDown(event: cc.Event.EventKeyboard) {
        switch (event.keyCode) {
            case cc.macro.KEY.left:
                this.moveDir = -1;
                break;
            case cc.macro.KEY.right:
                this.moveDir = 1;
                break;
            case cc.macro.KEY.space:
                if (this.isGrounded) {
                    const impulse = cc.v2(0, this.jumpImpulse * this.rb.getMass());
                    this.rb.applyLinearImpulse(impulse, this.rb.getWorldCenter(), true);
                    this.isGrounded = false;
                                    // 播放跳躍音效
                    if (this.jumpSound) {
                        cc.audioEngine.playEffect(this.jumpSound, false);
                    }
                

                    // 撥放跳躍動畫（可選）
                    this.getComponent(cc.Animation).play("jump");
                }
                break;
            case cc.macro.KEY.z:
                this.gameMgrNode.getComponent(GameMgr).gameOver();
                console.log("生命值減少");
                break;
        }
    }

    onKeyUp(event: cc.Event.EventKeyboard) {
        if (event.keyCode === cc.macro.KEY.left || event.keyCode === cc.macro.KEY.right) {
            this.moveDir = 0;
            this.node.getComponent(cc.Animation).stop("walk");
        }
    }

    onBeginContact(contact, selfCollider, otherCollider) {
        const normal = contact.getWorldManifold().normal;
        console.log("接觸到:", otherCollider.node.group);

        if (otherCollider.node.group === "PhyMap") {
            if (normal.y < -0.7) {
                console.log("踩到地板");
                this.isGrounded = true;
                this.isTouchingWall = false;
                
            } else if (Math.abs(normal.x) > 0.7) {
                console.log("側邊撞到地面");
                this.isTouchingWall = true;
            
            }
        } else if (otherCollider.node.group === "Enemy") {
            if (normal.y < -0.7) {
                console.log("踩到敵人");
                
                                // 播放跳躍音效
                if (this.beatSound) {
                    cc.audioEngine.playEffect(this.beatSound, false);
                }

                if (this.gameMgrNode) {
                    this.gameMgrNode.getComponent(GameMgr).updateScore(100); // 每次踩到敵人加 100 分
                        
                    
                }

                const impulse = cc.v2(0, this.jumpImpulse * this.rb.getMass() *0.7);
                this.rb.applyLinearImpulse(impulse, this.rb.getWorldCenter(), true);
                this.getComponent(cc.Animation).play("jump");
                this.isGrounded = false;
                otherCollider.node.getComponent("enemy").die();
            } else {
                if (this.isInvincible) {
                    console.log("玩家處於無敵狀態，忽略碰撞");
                    return; // 跳過碰撞處理
                }
                console.log("碰到敵人", this.isBig);

                if (this.isBig) {
                    // 玩家變大時，先變回原本大小
                    console.log("玩家受到攻擊，變回原本大小！");
                    this.shrink(); // 調用 shrink 方法
                    this.activateInvincibility(); // 啟動無敵狀態
                } else {
                    // 玩家原本大小時，扣血並結束遊戲
                    console.log("玩家死亡！");
                    this.gameMgrNode.getComponent(GameMgr).gameOver(); // 調用 GameMgr 的 gameOver 方法
                }
            }
        } else if (otherCollider.node.group === "Queblock") {
            if (normal.y > 0.7){
                
                otherCollider.node.getComponent("QuestionBlock").activate();
            }
            
        } else if (otherCollider.node.group === "Mushroom") {
            
            otherCollider.node.destroy(); // 摧毀蘑菇
            this.grow();
        } else if (otherCollider.node.group === "flower") {
            if (this.isInvincible) {
                console.log("玩家處於無敵狀態，忽略碰撞");
                return; // 跳過碰撞處理
            }
            console.log("碰到敵人", this.isBig);

            if (this.isBig) {
                // 玩家變大時，先變回原本大小
                console.log("玩家受到攻擊，變回原本大小！");
                this.shrink(); // 調用 shrink 方法
                this.activateInvincibility(); // 啟動無敵狀態
            } else {
                // 玩家原本大小時，扣血並結束遊戲
                console.log("玩家死亡！");
                this.gameMgrNode.getComponent(GameMgr).gameOver(); // 調用 GameMgr 的 gameOver 方法
            }
        }
    }

    onEndContact(contact, selfCollider, otherCollider) {
        if (otherCollider.node.group === "PhyMap") {
            this.isTouchingWall = false;
            this.isGrounded = false;
        }
    }

    onDestroy() {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    }

    grow() {
        if( this.isBig) 
            return; // 如果已經變大，則不再處理
        console.log("玩家變大！");
        cc.audioEngine.playEffect(this.PowerUp, false); // 播放吃蘑菇音效
        this.node.scale = 1.5; // 調整玩家大小
        // 調整剛體質量
        const rb = this.getComponent(cc.RigidBody);
        // 調整剛體密度
        const collider = this.getComponent(cc.PhysicsCollider); // 獲取碰撞體
        if (collider) {
            collider.density = 0.5; // 減小密度，避免質量過大
            collider.apply(); // 應用更改
        }
        this.isBig = true; // 設置玩家為變大狀態
    }

    activateInvincibility() {
        this.isInvincible = true; // 設置為無敵狀態
        console.log("玩家進入無敵狀態");


        // 0.5 秒後取消無敵狀態
        this.scheduleOnce(() => {
            this.isInvincible = false;
            console.log("玩家無敵狀態結束");
        }, 0.5);
    }
    shrink() {
        if( !this.isBig)
            return; // 如果已經是小隻，則不再處理
        console.log("玩家縮小！");
        cc.audioEngine.playEffect(this.PowerDown, false); // 播放縮小音效
        this.node.scale = 1; // 恢復玩家大小
        this.isBig = false; // 更新狀態

        // 恢復剛體密度
        const collider = this.getComponent(cc.PhysicsCollider); // 獲取碰撞體
        if (collider) {
            collider.density = 1; // 恢復原本密度
            collider.apply(); // 應用更改
        }
    }
}
