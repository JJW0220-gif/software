const { ccclass, property } = cc._decorator;
import GameMgr from "./gameMgr";

enum EnemyState {
    Normal,       // 正常狀態
    ShellStatic,  // 龜殼靜止
    ShellMoving   // 龜殼橫掃
}

@ccclass
export default class Enemy extends cc.Component {
    @property(cc.Node)
    gameMgrNode: cc.Node = null; // 用來綁定 GameMgr 節點

    @property
    moveSpeed: number = 300; // 移動速度

    /*@property(cc.Prefab)
    enemyPrefab: cc.Prefab = null;*/

    private originX: number = 0;
    @property
    moveRange: number = 200;

    private moveDirection: number = 1; // 移動方向（1 表示向右，-1 表示向左）
    //private isDead: boolean = false;
    private state: EnemyState = EnemyState.Normal; // 初始狀態為正常

    start(): void {
        this.scheduleOnce(() => {
            if (!this.gameMgrNode) {
                console.error("❌ gameMgrNode 還是 null！（延遲檢查）");
            } else {
                console.log("✅ gameMgrNode 綁定成功 enemy：", this.gameMgrNode.name);
            }
        }, 5); // 下一幀再執行
        // 隨機初始化移動方向
        this.moveDirection = Math.random() > 0.5 ? 1 : -1;

        // 確保剛體不會旋轉
        const rigidBody = this.getComponent(cc.RigidBody);
        if (rigidBody) {
            rigidBody.fixedRotation = true;
        }
        this.state = EnemyState.Normal; // 初始化狀態為正常
        this.originX = this.node.x; // 記錄初始位置
        
    }

    update(dt: number): void {
         this.node.angle = 0;
        if (this.state === EnemyState.Normal) {
            this.handleNormalState();
        } else if (this.state === EnemyState.ShellMoving) {
            this.handleShellMovingState();
        } else {
            this.node.getComponent(cc.Animation)?.play("enemydefault");
        }
    }

    handleNormalState() {
        const rigidBody = this.getComponent(cc.RigidBody);
        if (rigidBody) {
            const vx = this.moveDirection * this.moveSpeed * 0.5;
            rigidBody.linearVelocity = cc.v2(vx, rigidBody.linearVelocity.y);
        }

        // 根據移動方向調整節點的 scaleX
        if (this.moveDirection > 0) {
            this.node.scaleX = - 1; // 向右移動，鏡像
        } else if (this.moveDirection < 0) {
            this.node.scaleX = 1; // 向左移動，正常
        }

        const animation = this.node.getComponent(cc.Animation);
        if (animation && !animation.getAnimationState("enemywalk").isPlaying) {
            animation.play("enemywalk");
            console.log(animation.getAnimationState("enemywalk").isPlaying)
            console.log("enemywalk 播放");
        }

        // 邊界檢查，反轉方向
        if (this.node.x <= this.originX - this.moveRange && this.moveDirection < 0) {
            this.moveDirection = 1;
        } else if (this.node.x >= this.originX + this.moveRange && this.moveDirection > 0) {
            this.moveDirection = -1;
        }
    }

    handleShellMovingState() {
        const rigidBody = this.getComponent(cc.RigidBody);
        if (rigidBody) {
            const vx = this.moveDirection * this.moveSpeed * 1.5;
            rigidBody.linearVelocity = cc.v2(vx, rigidBody.linearVelocity.y);
        }

        // 根據移動方向調整節點的 scaleX
        if (this.moveDirection > 0) {
            this.node.scaleX = 1; // 向右移動，正常
        } else if (this.moveDirection < 0) {
            this.node.scaleX = -1; // 向左移動，鏡像
        }

        const animation = this.node.getComponent(cc.Animation);
        if (animation && !animation.getAnimationState("enemydead").isPlaying) {
            animation.play("enemydead");

        }

        // 邊界檢查，反轉方向
        if (this.node.x <= this.originX - this.moveRange && this.moveDirection < 0) {
            this.moveDirection = 1;
        } else if (this.node.x >= this.originX + this.moveRange && this.moveDirection > 0) {
            this.moveDirection = -1;
        }       
    }

    die() {
        console.log("敵人轉換型態")
        if(this.state === EnemyState.Normal || this.state === EnemyState.ShellMoving) {
            this.state = EnemyState.ShellStatic; // 切換到龜殼靜止狀態
            if (this.gameMgrNode) {
                const gameMgr = this.gameMgrNode.getComponent("GameMgr");
                if (gameMgr) {
                    gameMgr.updateScore(100); // 每次踩到敵人加 100 分
                }
            }
            this.node.getComponent(cc.Animation)?.play("enemydefault"); // 播放靜止動畫
        } else if (this.state === EnemyState.ShellStatic) {
            this.state = EnemyState.ShellMoving; // 切換回正常狀態

        }     
        // 延遲修改剛體類型，避免在物理回調中直接修改
        /*this.scheduleOnce(() => {
            const rigidBody = this.getComponent(cc.RigidBody);
            if (rigidBody) {
                rigidBody.type = cc.RigidBodyType.Static;
            }
            this.node.getComponent(cc.Animation)?.play("default"); // 播放死亡動畫
            this.scheduleOnce(() => this.node.destroy(), 0.5); // 延遲銷毀節點
        }, 0);*/
    }
}