const { ccclass, property } = cc._decorator;

@ccclass
export default class Login extends cc.Component {
    @property(cc.EditBox)
    emailInput: cc.EditBox = null; // Email 輸入框

    @property(cc.EditBox)
    passwordInput: cc.EditBox = null; // 密碼輸入框

    @property(cc.Label)
    statusLabel: cc.Label = null; // 狀態顯示標籤

    /*@property(cc.EditBox)
    nameInput: cc.EditBox = null; // 名字輸入框

    @property(cc.Node)
    nameInputContainer: cc.Node = null; // 包含名字輸入框的節點*/

    start() {
        // 綁定按鈕事件到 onLoginClick
        const loginButton = cc.find("Canvas/confirm");
        if (loginButton) {
            loginButton.on("click", this.onLoginClick, this);
            console.log("Login 按鈕綁定成功");
        } else {
            console.error("LoginButton 節點未找到！");
        }

    }

    onLoginClick() {
        const email = this.emailInput.string.trim();
        const password = this.passwordInput.string.trim();

        if (!email || !password) {
            this.statusLabel.string = "請輸入有效的 Email 和密碼";
            return;
        }

        firebase.auth().signInWithEmailAndPassword(email, password)
            .then((userCredential) => {
                const user = userCredential.user;
                this.statusLabel.string = "登入成功！";
                console.log("登入成功:", user);
                // 跳轉到主菜單或其他場景
                cc.director.loadScene("Menu");

            })
            .catch((error) => {
                console.error("登入失敗:", error.message);
                this.statusLabel.string = `登入失敗: ${error.message}`;
            });
    }

    /*onNameConfirm(uid: string) {
        const name = this.nameInput.string.trim();
        if (!name) {
            this.statusLabel.string = "請輸入名字";
            return;
        }

    // 將名字添加到 Firebase 的 names 節點
    const nameRef = firebase.database().ref(`users/${uid}/names`);
    nameRef.push(name)
        .then(() => {
            console.log("名字已存儲到 Firebase:", name);
            this.statusLabel.string = "名字已保存！";

            // 跳轉到主菜單或其他場景
            cc.sys.localStorage.setItem("showLevelMenu", "true");
            cc.director.loadScene("Menu");
        })
        .catch((error) => {
            console.error("存儲名字失敗:", error.message);
            this.statusLabel.string = `存儲名字失敗: ${error.message}`;
        });
    }*/
}