const { ccclass, property } = cc._decorator;

@ccclass
export default class SignUp extends cc.Component {
    @property(cc.EditBox)
    emailInput: cc.EditBox = null; // Email 輸入框

    @property(cc.EditBox)
    passwordInput: cc.EditBox = null; // 密碼輸入框

    @property(cc.Label)
    statusLabel: cc.Label = null; // 狀態顯示標籤

    @property(cc.EditBox)
    nameInput: cc.EditBox = null; // 名字輸入框

    @property(cc.Node)
    nameInputContainer: cc.Node = null; // 包含名字輸入框的節點

    start() {
        // 綁定按鈕事件到 onSignUpClick
        const signUpButton = cc.find("Canvas/confirm");
        if (signUpButton) {
            signUpButton.on("click", this.onSignUpClick, this);
            console.log("SignUp 按鈕綁定成功");
        } else {
            console.error("SignUpButton 節點未找到！");
        }

                // 隱藏名字輸入框
        if (this.nameInputContainer) {
            this.nameInputContainer.active = false;
        }
    }

    onSignUpClick() {
        const email = this.emailInput.string.trim();
        const password = this.passwordInput.string.trim();

        if (!email || !password) {
            this.statusLabel.string = "請輸入有效的 Email 和密碼";
            return;
        }

    

    firebase.auth().createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            const user = userCredential.user;
            this.statusLabel.string = "註冊成功！";
            console.log("註冊成功:", user);

            // 將用戶信息存儲到 Firebase Realtime Database
            if (user) {
                firebase.database().ref(`users/${user.uid}`).set({
                    email: user.email,
                    createdAt: new Date().toISOString(),
                    progress: {
                        level1Cleared: false,
                        level2Cleared: false
                    }
                }).then(() => {
                    console.log("用戶信息已存儲到 Firebase");
                }).catch((error) => {
                    console.error("存儲用戶信息失敗:", error.message);
                });
            }
            this.nameInputContainer.active = true;
            cc.find("Canvas/name/back").on("click", this.onNameConfirm, this);
            
        })
        .catch((error) => {
            console.error("註冊失敗:", error.message);
            this.statusLabel.string = `註冊失敗: ${error.message}`;
        });
    }

onNameConfirm() {
    const name = this.nameInput.string.trim();
    if (!name) {
        this.statusLabel.string = "請輸入名字";
        return;
    }

    const user = firebase.auth().currentUser;
    if (!user) {
        console.error("用戶未登入，無法存名字");
        this.statusLabel.string = "請先登入";
        return;
    }

    const uid = user.uid;

    // 儲存到 Firebase
    const nameRef = firebase.database().ref(`users/${uid}/names`);
    nameRef.push(name)
        .then(() => {
            console.log("名字已存儲到 Firebase:", name);
            this.statusLabel.string = "名字已保存！";

            cc.director.loadScene("Menu");
        })
        .catch((error) => {
            console.error("存儲名字失敗:", error.message);
            this.statusLabel.string = `存儲名字失敗: ${error.message}`;
        });
}

}