const { ccclass, property } = cc._decorator;

@ccclass
export default class Mushroom extends cc.Component {
    @property
    moveSpeed: number = -100;

    private rb: cc.RigidBody = null;

    start() {
        this.rb = this.getComponent(cc.RigidBody);
        this.rb.linearVelocity = cc.v2(this.moveSpeed, 0); // 自動往左移
        this.rb.fixedRotation = true;
    }

    update(dt: number) {
        // 確保水平速度保持一致
        if (this.rb) {
            this.rb.linearVelocity = cc.v2(this.moveSpeed, this.rb.linearVelocity.y);
        }
    }
}