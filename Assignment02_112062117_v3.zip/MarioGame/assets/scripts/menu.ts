import Login from "./Login";

const { ccclass, property } = cc._decorator;

// 自定義排行榜資料型別
type LeaderboardEntry = {
    name: string;
    score: number;
};

@ccclass
export default class menu extends cc.Component {
    @property({ type: cc.AudioClip })
    menuBgm: cc.AudioClip = null;

    @property(cc.Node)
    levelMenu: cc.Node = null;  // 拖入 Canvas/LevelMenu

    @property(cc.Node)
    leaderboardPanel: cc.Node = null; // 排行榜面板

    @property(cc.Label)
    leaderboardContent: cc.Label = null; // 排行榜內容顯示

    private bgmId: number = null;
    onLoad() {
         // 播放選單音樂
        if (this.menuBgm) {
            this.bgmId = cc.audioEngine.playMusic(this.menuBgm, true);
        }

        if(cc.sys.localStorage.getItem("showLevelMenu") ==="null") {
            cc.sys.localStorage.setItem("showLevelMenu", "false");
        }

    }
    start() {

                // 綁定返回按鈕事件
        const backButton = cc.find("Canvas/Back");
        if (backButton) {
            backButton.on("click", this.hideLeaderboard, this);
            console.log("返回按鈕綁定成功");
        } else {
            console.error("BackButton 節點未找到！");
        }
        backButton.active = false; // 初始時隱藏返回按鈕

            // 綁定 Level1 排行榜按鈕事件
        const level1LeaderboardButton = cc.find("Canvas/LevelNode/level1_leader");
        if (level1LeaderboardButton) {
            level1LeaderboardButton.on("click", () => this.showLeaderboard("main"), this);
            console.log("Level1 排行榜按鈕綁定成功");
        } else {
            console.error("Level1LeaderboardButton 節點未找到！");
        }

        // 綁定 Level2 排行榜按鈕事件
        const level2LeaderboardButton = cc.find("Canvas/LevelNode/level2_leader");
        if (level2LeaderboardButton) {
            level2LeaderboardButton.on("click", () => this.showLeaderboard("main2"), this);
            console.log("Level2 排行榜按鈕綁定成功");
        } else {
            console.error("Level2LeaderboardButton 節點未找到！");
        }

        // 隱藏排行榜面板
        if (this.leaderboardPanel) {
            this.leaderboardPanel.active = false;
        }

            // 綁定 Login 按鈕事件
        const loginButton = cc.find("Canvas/login");
        if (loginButton) {
            loginButton.on("click", () => this.loadLevel("LoginScene"), this);
            console.log("Login 按鈕綁定成功");
        } else {
            console.error("LoginButton 節點未找到！");
        }

        // 綁定 Sign Up 按鈕事件
        const signUpButton = cc.find("Canvas/signup");
        if (signUpButton) {
            signUpButton.on("click", () => this.loadLevel("SignUpScene"), this);
            console.log("Sign Up 按鈕綁定成功");
        } else {
            console.error("SignUpButton 節點未找到！");
        }

        // Import the functions you need from the SDKs you need
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
    const firebaseConfig = {
        apiKey: "AIzaSyBGDJKv0JHtoiJ6fVw2dDZYOVrzdU_EnVM",
        authDomain: "mario-e2666.firebaseapp.com",
        databaseURL: "https://mario-e2666-default-rtdb.firebaseio.com",
        projectId: "mario-e2666",
        storageBucket: "mario-e2666.firebasestorage.app",
        messagingSenderId: "961869529782",
        appId: "1:961869529782:web:d9bdc2f9bec4d254231c17",
        measurementId: "G-3M9NCTHBYY"
        };

// Initialize Firebase
        const app = firebase.initializeApp(firebaseConfig);

        // 設定 StartButton 點擊事件
    const startButtonNode = cc.find("Canvas/StartButton");
    const startButton = startButtonNode?.getComponent(cc.Button);

    // 檢查登入狀態
    firebase.auth().onAuthStateChanged((user) => {
        if (user) {
            console.log("✅ 使用者已登入:", user.email);
            // 啟用 StartButton
            if (startButton) {
                startButton.interactable = true;
                startButtonNode.active = true;
            }
        } else {
            console.warn("⚠ 尚未登入，StartButton 將被禁用");
            if (startButton) {
                startButton.interactable = false;  // 停用按鈕點擊
                startButtonNode.active = true;     // 顯示，但無法按
                // 或：startButtonNode.active = false; // 直接隱藏
            }
        }
    });

        const Start = new cc.Component.EventHandler();
        Start.target = this.node;
        Start.component = "menu";
        Start.handler = "onStartClick";

        startButtonNode.getComponent(cc.Button).clickEvents.push(Start);

        // 關卡選單預設關閉
        this.levelMenu.active = false;
        const showLevelMenu = cc.sys.localStorage.getItem("showLevelMenu")
        console.log("showLevelMenu:", showLevelMenu);
        if(showLevelMenu === "true") {
            this.levelMenu.active = true;
            signUpButton.active = false;
            loginButton.active = false;
            cc.find("Canvas/StartButton").active = false;
        }
        cc.sys.localStorage.removeItem("showLevelMenu"); // 清除 showLevelMenu 的值

        console.log("音樂ID:", this.bgmId);
        // 設定 Level1 / Level2 的點擊事件
        const level1Button = cc.find("Canvas/LevelNode/Level");
        const level2Button = cc.find("Canvas/LevelNode/Level2");

        if (level1Button) {
            level1Button.on("click", () => this.loadLevel("main"), this);
            console.log("Level1 綁定成功");
        } else {
            console.error("Level1Button 節點未找到！");
        }

        if (level2Button) {
            level2Button.on("click", () => this.loadLevel("main2"), this);
            console.log("Level2 綁定成功");
        } else {
            console.error("Level2Button 節點未找到！");
        }

        firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        console.log("使用者已登入，檢查遊戲進度");

        // 從 Firebase 拿進度
        firebase.database().ref(`users/${user.uid}/progress`).once("value")
            .then((snapshot) => {
                const progress = snapshot.val();

                const level2ButtonNode = cc.find("Canvas/LevelNode/Level2");
                const level2Button = level2ButtonNode?.getComponent(cc.Button);

                if (!progress || !progress.level1Cleared) {
                    console.log("尚未通過 Level 1，禁用 Level 2 按鈕");
                    if (level2Button) {
                        level2Button.interactable = false; // ✅ 禁用按鈕
                    }
                    // 可選：整個隱藏按鈕
                    // level2ButtonNode.active = false;
                } else {
                    console.log("Level 1 已通過，可進入 Level 2");
                    if (level2Button) {
                        level2Button.interactable = true;
                    }
                }
            })
            .catch((error) => {
                console.error("讀取遊戲進度失敗:", error.message);
            });
        }
    });
    firebase.auth().onAuthStateChanged((user) => {
        if (user) {
            console.log("使用者已登入，檢查遊戲進度");

            // 從 Firebase 拿進度
            firebase.database().ref(`users/${user.uid}/progress`).once("value")
                .then((snapshot) => {
                    const progress = snapshot.val();

                    const level2ButtonNode = cc.find("Canvas/LevelNode/Level2");
                    const level2Button = level2ButtonNode?.getComponent(cc.Button);

                    if (!progress || !progress.level1Cleared) {
                        console.log("尚未通過 Level 1，禁用 Level 2 按鈕");
                        if (level2Button) {
                            level2Button.interactable = false; // ✅ 禁用按鈕
                        }
                        // 可選：整個隱藏按鈕
                        // level2ButtonNode.active = false;
                    } else {
                        console.log("Level 1 已通過，可進入 Level 2");
                        if (level2Button) {
                            level2Button.interactable = true;
                        }
                    }
                })
                .catch((error) => {
                    console.error("讀取遊戲進度失敗:", error.message);
                });
            }
        });
    }

    onStartClick() {
        cc.find("Canvas/StartButton").active = false;
        this.levelMenu.active = true;
        cc.find("Canvas/login").active = false;
        cc.find("Canvas/signup").active = false;
    }

    loadLevel(sceneName: string) {
        if (this.bgmId !== null) {
            cc.audioEngine.stopMusic();
        }
    // 嘗試加載場景，並添加錯誤處理
        cc.director.loadScene(sceneName, (err) => {
            if (err) {
                console.error(`無法加載場景: ${sceneName}`, err);
            } else {
                console.log(`成功加載場景: ${sceneName}`);
            }
        });
    }

    // 從 Firebase 獲取排行榜數據
showLeaderboard(level: string) {
    if (!this.leaderboardPanel || !this.leaderboardContent) {
        console.error("排行榜面板或內容節點未設置！");
        return;
    }

    // 顯示排行榜面板和返回按鈕
    this.leaderboardPanel.active = true;
    cc.find("Canvas/Back").active = true;
    cc.find("Canvas/StartButton").active = false;

// 從 Firebase 獲取排行榜數據
// 從 Firebase 獲取排行榜數據
firebase.database().ref(`leaderboard/${level}`)
    .orderByChild("score")
    .limitToLast(5)
    .once("value")
    .then((snapshot) => {
        const data = snapshot.val();
        console.log("排行榜數據:", data); // 除錯輸出
        this.levelMenu.active = false; // 隱藏關卡選單

        if (data) {
            // 將資料轉為陣列 + 明確型別 + 依分數降序排列
            const sortedData: LeaderboardEntry[] = Object.entries(data)
                .map(([key, value]) => value as LeaderboardEntry)
                .sort((a, b) => b.score - a.score);

            // 構建排行榜文字
            let content = `🏆 排行榜 (${level})\n`;
            sortedData.forEach((entry, index) => {
                content += `${index + 1}. ${entry.name || "Unknown"}: ${entry.score}\n`;
            });

            // 顯示排行榜內容
            this.leaderboardContent.string = content;

        } else {
            this.leaderboardContent.string = `排行榜 (${level}) 暫無數據`;
        }
    })
    .catch((error) => {
        console.error("獲取排行榜數據失敗:", error.message);
        this.leaderboardContent.string = "❌ 獲取排行榜數據失敗";
    });

}

    hideLeaderboard() {
        if (this.leaderboardPanel) {
            this.leaderboardPanel.active = false; // 隱藏排行榜面板
        }
        if (this.levelMenu) {
            this.levelMenu.active = true; // 顯示關卡選單
        }
        cc.find("Canvas/Back").active = false; // 隱藏返回按鈕
    }
}
