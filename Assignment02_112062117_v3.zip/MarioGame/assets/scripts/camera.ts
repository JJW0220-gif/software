const { ccclass, property } = cc._decorator;

@ccclass
export default class CameraFollow extends cc.Component {
    @property(cc.Node)
    target: cc.Node = null;  // 拖曳你的 Player 進來

    @property
    followX: boolean = true;

    @property
    followY: boolean = true;

    // 新增邊界屬性
    minX: number = 10;
    maxX: number = 7350;
    minY: number = 0;
    maxY: number = 300;

    @property(cc.Node)
    lifeBar: cc.Node = null; // 拖入血條節點
    @property(cc.Node)
    frame: cc.Node = null; // 拖入血條框
    @property(cc.Node)
    pause: cc.Node = null; //暫停icon
    @property(cc.Node)
    pausePage: cc.Node = null; //暫停頁面
    @property(cc.Node)
    continue: cc.Node = null; //繼續按鈕
    @property(cc.Node)
    quit: cc.Node = null; //退出按鈕 
    @property(cc.Label)
    timerLabel: cc.Label = null; // 拖入用於顯示倒數時間的 Label 節點
    @property(cc.Label)
    score: cc.Label = null; // 拖入用於顯示倒數時間的 Label 節點
    @property(cc.Node)
    gameover: cc.Node = null;


    update(dt: number) {
        if (!this.target) return;

        const cameraPos = this.node.position;
        const targetPos = this.target.position;

        // 計算要跟隨的目標座標
        let newX = this.followX ? targetPos.x : cameraPos.x;
        let newY = this.followY ? targetPos.y : cameraPos.y;

        // 限制邊界
        newX = Math.max(this.minX, Math.min(this.maxX, newX));
        newY = Math.max(this.minY, Math.min(this.maxY, newY));

        this.node.setPosition(newX, newY);

        this.updateLifeBarPosition();
        
    }
    updateLifeBarPosition() {
        if (!this.lifeBar) {
            console.error("lifeBar 節點未正確綁定！");
            return;
        }

        // Camera 的左上角（世界座標）
        const canvasSize = cc.view.getVisibleSize();
        const offsetX = 10;
        const offsetY = -10;

        const worldTopLeft = this.node.convertToWorldSpaceAR(
            cc.v2(-431.083, 272.207)
        );
        const worldTopLeft2 = this.node.convertToWorldSpaceAR(
            cc.v2(-353.404, 246.228)
        );

        const worldTopright = this.node.convertToWorldSpaceAR(
            cc.v2(443.651, 267.599)
        );
        const worldcenter = this.node.convertToWorldSpaceAR(
            cc.v2(0, 0)
        );
        const worldcenter2 = this.node.convertToWorldSpaceAR(
            cc.v2(2.858, 0)
        );
        const worldcenter3 = this.node.convertToWorldSpaceAR(
            cc.v2(-67.605, -77.723)
        );
        const worldcentertop = this.node.convertToWorldSpaceAR(
            cc.v2(-2.532, 260.798)
        );

        const worldTopRight2 = this.node.convertToWorldSpaceAR(
            cc.v2(300.689, 267.599)
        );

        const dead = this.node.convertToWorldSpaceAR(
            cc.v2(32.415, 0)
        );

        // 將世界座標轉成 UI 所在父節點的本地座標
        const uiRoot = this.lifeBar.parent; // HPbar
        const uiRoot2 = this.pausePage.parent; // gameMgr
        const localPos = uiRoot.convertToNodeSpaceAR(worldTopLeft);
        const localPos2 = uiRoot.convertToNodeSpaceAR(worldTopLeft2);
        const localPos3 = uiRoot.convertToNodeSpaceAR(worldTopright);
        const localPos4 = uiRoot2.convertToNodeSpaceAR(worldcenter);
        const localPos5 = uiRoot2.convertToNodeSpaceAR(worldcenter2);
        const localPos6 = uiRoot2.convertToNodeSpaceAR(worldcenter3);
        const localPos7 = uiRoot.convertToNodeSpaceAR(worldcentertop);
        const localPos8 = uiRoot.convertToNodeSpaceAR(worldTopRight2);
        const localPos9 = uiRoot2.convertToNodeSpaceAR(dead);

        this.lifeBar.setPosition(localPos);
        this.frame.setPosition(localPos2);
        this.pause.setPosition(localPos3);
        this.pausePage.setPosition(localPos4);
        this.continue.setPosition(localPos5);
        this.quit.setPosition(localPos6);
        this.timerLabel.node.setPosition(localPos7);
        this.score.node.setPosition(localPos8);
        this.gameover.setPosition(localPos4);
    } 

}
