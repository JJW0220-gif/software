const { ccclass, property } = cc._decorator;

@ccclass
export default class QuestionBlock extends cc.Component {
    @property(cc.SpriteFrame)
    usedSprite: cc.SpriteFrame = null; // 問號變空磚的圖

    @property(cc.Prefab)
    mushroomPrefab: cc.Prefab = null; // 掉出來的蘑菇

    @property({ type: cc.AudioClip })
    boxSound: cc.AudioClip = null; // 跳躍音效

    private used: boolean = false;

    start() {
        // 初始化時，確保磚塊是未使用狀態
        this.used = false;
        // 確保使用的圖已經設定
        if (!this.usedSprite) {
            console.error("❌ usedSprite 尚未設定！");
        }
    }


    activate() {

        if (this.used) {
            // 如果已經使用過，則不再處理
            return;
        }
        cc.audioEngine.playEffect(this.boxSound, false); // 播放磚塊音效
        this.used = true;
        // 換圖變成用過的磚塊
        this.getComponent(cc.Sprite).spriteFrame = this.usedSprite;

        // 產生蘑菇
        const mushroom = cc.instantiate(this.mushroomPrefab);
        mushroom.parent = this.node.parent;
        mushroom.setPosition(this.node.x, this.node.y + 32); // 從方塊上面冒出來*/
    }
}
