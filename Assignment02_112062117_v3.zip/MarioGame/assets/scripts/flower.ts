const { ccclass, property } = cc._decorator;

@ccclass
export default class FlowerEnemy extends cc.Component {
    @property
    moveSpeed: number = 50; // 上下移動速度

    @property
    moveRange: number = 100; // 上下移動範圍

    private startY: number = 0; // 初始位置
    private direction: number = 1; // 移動方向


    onLoad() {
        this.startY = this.node.y; // 記錄初始位置

        // 禁用重力影響
        const rb = this.getComponent(cc.RigidBody);
        if (rb) {
            rb.gravityScale = 0; // 設置重力影響為 0
        }

        const rigidBody = this.getComponent(cc.RigidBody);
        if (rigidBody) {
            rigidBody.fixedRotation = true;
        }
    }

    update(dt: number) {
        
        // 上下移動邏輯
        this.node.y += this.direction * this.moveSpeed * dt;

        // 超出範圍時反向
        if (this.node.y > this.startY + this.moveRange && this.direction > 0) {
            
            this.direction = 0; // 停止移動
            
            this.getComponent(cc.Animation).play("flower");
        // 1 秒後恢復移動
            this.scheduleOnce(() => {
                this.direction = -1; // 反向向下移動
                this.getComponent(cc.Animation).stop("flower");
                
            }, 1);
        } else if (this.node.y < this.startY && this.direction < 0) {
            this.direction = 1;
        }
    }
}