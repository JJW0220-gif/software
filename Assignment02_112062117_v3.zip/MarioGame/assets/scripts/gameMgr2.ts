import Player from "./player2";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GameMgr extends cc.Component {
    
    @property(Player)
    player: Player = null;
    
    @property(cc.Node)
    gameOverScreen: cc.Node = null; // 用於顯示 Game Over 畫面

    @property(cc.Node)
    startIcon: cc.Node = null;

    

    @property(cc.Node)
    pauseIcon: cc.Node = null;

    @property(cc.Node)
    pausePage: cc.Node = null;

    @property({ type: cc.AudioClip })
    bgm: cc.AudioClip = null;

    @property(cc.Node)
    private continue: cc.Node = null; // 繼續按鈕

    @property(cc.Node)
    private lifeBar: cc.Node = null;

    @property(cc.Node)
    private frame: cc.Node = null; // 拖入血條節點

    @property(cc.Label)
    timerLabel: cc.Label = null; // 拖入用於顯示倒數時間的 Label 節點

    @property(cc.Node)
    private quit: cc.Node = null; // 退出按鈕

    @property(cc.Prefab)
    enemyPrefab: cc.Prefab = null;

    @property(cc.Node)
    enemyParent: cc.Node = null; // 建議建立一個空節點 EnemyLayer 用來裝敵人

    @property({ type: cc.AudioClip })
    dieSound: cc.AudioClip = null; // 死亡音效

    @property({ type: cc.AudioClip })
    winsound: cc.AudioClip = null; // 跳躍音效

    @property({ type: cc.AudioClip })
    losesound: cc.AudioClip = null; // 跳躍音效

    @property(cc.Label)
    scoreLabel: cc.Label = null; // 用於顯示分數的 Label

    @property(cc.Prefab)
    questionBlockPrefab: cc.Prefab = null; // 問號磚塊的預製體

    @property(cc.Node)
    questionBlockParent: cc.Node = null; // 用於存放生成的問號磚塊

    private score: number = 0; // 玩家分數

    private maxLives: number = 5; // 最大生命值
    private currentLives: number = 5; // 當前生命值

    private countdownTime: number = 90; // 倒數時間（秒）
    private timerRunning: boolean = false; // 計時器是否正在運行


    onLoad() {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        this.pauseIcon.on(cc.Node.EventType.TOUCH_END, this.onPauseClick, this);
        this.continue.on(cc.Node.EventType.TOUCH_END, this.resumeGame, this);
        this.quit.on(cc.Node.EventType.TOUCH_END, this.win, this);
        
        this.gameStart();
        

    }



    

    onKeyDown(event: cc.Event.EventKeyboard) {
        switch (event.keyCode) {
            case cc.macro.KEY.a:
                this.gameStart();
                break;
            case cc.macro.KEY.d:
                this.gameOver();
                break;
            case cc.macro.KEY.s:
                this.win();
                break;
        }
    }

 

    gameStart() {
        console.log("Game Started!");

        // 顯示 Game Start 畫面
        this.gameOverScreen.active = false; // 確保遊戲結束畫面隱藏
        this.startIcon.active = true;
        this.player.node.active = false;
        this.lifeBar.active = false; // 隱藏生命條
        this.frame.active = false; // 隱藏生命條邊框
        this.pausePage.active = false; // 隱藏暫停頁面
        this.continue.active = false; // 隱藏繼續按鈕
        this.pauseIcon.active = false; // 顯示暫停按鈕
        this.quit.active = false; // 隱藏退出按鈕
        this.timerLabel.string = "1:30"; // 初始化計時器顯示為 1 分 30 秒
        this.countdownTime = 90; // 重置倒數時間為 90 秒
        this.timerRunning = false; // 重置計時器狀態
        this.player.node.setPosition(cc.v2(-251.415, 0)); // 重置玩家位置
        this.timerLabel.node.active = false; // 顯示計時器
        this.scoreLabel.node.active = false; // 顯示分數標籤
        cc.audioEngine.stopMusic(); // 停止背景音樂

        this.player.shrink(); // 重置為非變大狀態
        console.log("Player 已重置為小隻狀態");

        this.spawnEnemies();
        this.spawnQuestionBlocks(); // 生成問號磚塊
        
        // 延遲 1 秒後開始遊戲
        this.scheduleOnce(() => {
            this.lifeBar.active = true; // 顯示生命條
            this.startIcon.active = false; // 隱藏 Game Start 畫面
            this.frame.active = true; // 顯示生命條邊框
            this.player.node.active = true; // 啟用玩家
            this.pauseIcon.active = true; // 顯示暫停按鈕
            this.startTimer(); // 開始計時器
            this.timerLabel.node.active = true; // 顯示計時器
            cc.audioEngine.playMusic(this.bgm, true);
            this.resetScore(); // 重置分數
            console.log("Game Start!");
            this.scoreLabel.node.active = true; // 顯示分數標籤
            this.scoreLabel.string = `Score: ${this.score}`;
        }, 2); // 延遲 2 秒
    }

    spawnEnemies() {
        const positions = [
            cc.v2(200, 200),
            cc.v2(1100, 200),
            cc.v2(1900, 200),
            cc.v2(3600, 200),
            //cc.v2(1800, 250),
            cc.v2(5100, 200),
            cc.v2(7000, 250),
        ];

        for (let pos of positions) {
            this.spawnEnemy(pos);
        }
    }

    

    spawnEnemy(pos: cc.Vec2) {
        const enemy = cc.instantiate(this.enemyPrefab);
        console.log("⛳ 生成敵人位置：", pos); // ✅ 看看位置正不正確
        enemy.parent = this.enemyParent;
        if (!this.enemyParent) {
            console.warn("enemyParent 未設定，敵人將加到 GameMgr 節點下！");
            
        } else {
            console.log("enemyParent 設定成功，敵人將加到 enemyParent 節點下！");
        }
        enemy.setPosition(pos);

        const enemyScript = enemy.getComponent("Enemy");
        if (enemyScript) {
            enemyScript.gameMgrNode = this.node; // 綁定 GameMgr
            console.log( enemyScript.gameMgrNode, this.node);
            enemyScript.moveRange = 50;         // 設定移動範圍
        }
        console.log("敵人加入於：", enemy.parent.name);
    }

    spawnQuestionBlocks() {
        const positions = [
            cc.v2(400, 300), // 問號磚塊生成位置 1
            cc.v2(800, 300),
            cc.v2(1200, 300),
            cc.v2(6500, 200), // 問號磚塊生成位置 2
            cc.v2(3664.311, 50), // 問號磚塊生成位置 3
            cc.v2(1431.048, 125.989), // 問號磚塊生成位置 4
        ];

        // 清除之前的問號磚塊
        if (this.questionBlockParent) {
            this.questionBlockParent.children.forEach(block => {
                console.log("刪除問號磚塊:", block.name);
                block.destroy();
            });
        }

        // 生成新的問號磚塊
        for (let pos of positions) {
            const questionBlock = cc.instantiate(this.questionBlockPrefab);
            questionBlock.parent = this.questionBlockParent;
            questionBlock.setPosition(pos);
            console.log("生成問號磚塊於位置:", pos);
        }
    }

    gameOver() {
        this.player.node.active = false;

        console.log("Game Over!");

        this.updateLife(-1);
        this.clearEnemies(); // 刪除所有敵人
        
        // 延遲 1 秒後重新加載 main 場景
        this.scheduleOnce(() => {
            
            //cc.director.loadScene("main");
            this.gameStart(); // 重新開始遊戲
        }, 2); // 延遲 2 秒
    }

    win() {
        this.player.node.active = false;

        cc.audioEngine.playEffect(this.winsound, false); // 播放勝利音效
        console.log("You Win!");
        cc.sys.localStorage.setItem("showLevelMenu", "true");
        // 延遲 1 秒後關掉 main 場景
            // 獲取玩家的 UID
        const user = firebase.auth().currentUser;

        if (!user) {
            console.error("用戶未登入，無法儲存分數");
            cc.director.resume(); // 恢復遊戲
            this.scheduleOnce(() => {
                cc.director.loadScene("Menu");
            }, 1); // 延遲 1 秒*/
        }
        const uid = user.uid;

        firebase.database().ref(`users/${uid}/progress/level2Cleared`).set(true);

        // 從 Firebase 獲取玩家的名字
        firebase.database().ref(`users/${uid}/names`).once("value")
            .then((snapshot) => {
                const names = snapshot.val();
                const playerName = names ? Object.values(names)[0] : "Unknown Player"; // 使用第一個名字作為玩家名字
                const playerScore = this.score;

                // 儲存到 Firebase 的排行榜
                const level = cc.director.getScene().name; // 假設場景名稱是關卡名稱
                firebase.database().ref(`leaderboard/${level}`).push({
                    name: playerName,
                    score: playerScore
                }).then(() => {
                    console.log("玩家分數已儲存到 Firebase:", { name: playerName, score: playerScore });
                }).catch((error) => {
                    console.error("儲存玩家分數失敗:", error.message);
                });
            })
            .catch((error) => {
                console.error("獲取玩家名字失敗:", error.message);
            });

            console.log("back");

        //cc.director.loadScene("Menu");
        cc.director.resume(); // 恢復遊戲
        this.scheduleOnce(() => {
            cc.director.loadScene("Menu");
        }, 1); // 延遲 1 秒*/
    }
    updateLife(num: number){
        console.log("生命條長度:", this.lifeBar.width);
        const rec = this.currentLives;
        this.currentLives += num;
        if (this.currentLives > this.maxLives) this.currentLives = this.maxLives; // 防止生命值超過最大值
        const ratio = this. currentLives / rec;
        this.lifeBar.width = this.lifeBar.width * ratio;
        
        if(this.currentLives == 0) {
            this.gameOverScreen.active = true; // 顯示遊戲結束畫面
            cc.audioEngine.playEffect(this.losesound, false); // 播放失敗音效
            cc.sys.localStorage.setItem("showLevelMenu", "true");
            this.player.node.active = false;
            this.lifeBar.active = false; // 隱藏生命條
            this.frame.active = false; // 隱藏生命條邊框
            this.pausePage.active = false; // 隱藏暫停頁面
            this.continue.active = false; // 隱藏繼續按鈕
            this.pauseIcon.active = false; // 顯示暫停按鈕
            this.quit.active = false; // 隱藏退出按鈕
            this.timerRunning = false; // 重置計時器狀態
            this.timerLabel.node.active = false; // 顯示計時器
            this.scoreLabel.node.active = false; // 顯示分數標籤
            this.scheduleOnce(() => {
                cc.director.loadScene("Menu");
            }, 2); // 延遲 2秒*/
        }

        cc.audioEngine.playEffect(this.dieSound, false); // 播放死亡音效
    }

    onPauseClick() {
        this.pausePage.active = true; // 顯示暫停頁面
        this.continue.active = true; // 顯示繼續按鈕
        this.quit.active = true; // 顯示退出按鈕
        cc.audioEngine.pauseMusic(); // 暫停背景音樂
        cc.director.pause(); // 暫停遊戲
        console.log("遊戲已暫停");
    }


    resumeGame() {
        this.pausePage.active = false; // 隱藏暫停頁面
        this.continue.active = false; // 
        this.quit.active = false; // 隱藏退出按鈕
        cc.audioEngine.resumeMusic(); // 恢復背景音樂
        cc.director.resume(); // 恢復遊戲
        console.log("遊戲已恢復");
    }

    startTimer() {
        this.timerRunning = true;
        this.updateTimerLabel(); // 初始化顯示
        this.schedule(this.updateTimer, 1); // 每秒更新一次
    }

    updateTimer() {
        if (!this.timerRunning) return;

        this.countdownTime--;
        this.updateTimerLabel();

        if (this.countdownTime <= 0) {
            this.timerRunning = false;
            this.unschedule(this.updateTimer); // 停止計時
            console.log("時間到！");
            this.gameOver(); // 時間到後觸發遊戲結束
        }
    }
    updateTimerLabel() {
        const minutes = Math.floor(this.countdownTime / 60);
        const seconds = this.countdownTime % 60;
        this.timerLabel.string = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`; // 格式化為 MM:SS
    }

    clearEnemies() {
        if (this.enemyParent) {
            this.enemyParent.children.forEach(enemy => {
                console.log("刪除敵人:", enemy.name);
                enemy.destroy();
            });
        }
    }

        // 更新分數的方法
    updateScore(points: number) {
        this.score += points;
        this.scoreLabel.string = `Score: ${this.score}`;
        console.log(`玩家分數更新: ${this.score}`);
    }

    // 重置分數的方法
    resetScore() {
        this.score = 0;
        this.scoreLabel.string = `Score: ${this.score}`;
        console.log("分數已重置");
    }
}




